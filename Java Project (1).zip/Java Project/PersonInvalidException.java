public class PersonInvalidException extends Exception{
    PersonInvalidException(){
        super("Person Not Found");
    }
}